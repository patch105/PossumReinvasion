#!/usr/bin/env python
# coding: utf-8

#################################################################################
# Simulation scenario 'Maintenance High'
#################################################################################
# Audrey Lustig & Charlotte Patterson
# May 2022
# Scenario setup for a spread model predicting the repopulation of the common brushtail possum (Trichosurus vulpecula) on the Otago Peninsula, Dunedin, New Zealand.
# We tested management scenarios of repopulation across four factors (source population, maintenance trap density, residual population, buffer trap density).
# Scenario details are found in the main paper, Table 2
# Model inputs are a map of carrying capacities across the landscape and an optional map of trap density across the landscape, pest and trapping parameters, number of replicates, and time period.
# Parameters were set to average life history, dispersal, and trappability parameters for possums
# We ran scenarios for 40 years over 50 replicates
# Run in Python v. 3.7.4 

from __future__ import division
import random
import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats
from scipy import ndimage
from scipy import stats
from scipy.spatial import ConvexHull
import numba
import multiprocessing
import itertools
import sys
import glob, os
import gzip
import shutil


import habitat_suitability


####################################### Read suitability map
# Read habitat suitability. Map should be a raster file saved in ASCII format. 
# Each raster cell countain a float (carrying capacity of the predator under study)
# The maps use for our own experiment area of resolution 100m
filename_myhabitat = '~\\DHM_FORESTFRAGpeninsula_kmap_ascii_06_22' # habitat suitability as provided by the user


my_init_landscape=habitat_suitability.readMap(filename_myhabitat) #  read map of shape 

nbrow,nbcolumn = my_init_landscape.shape



my_habitat_K=my_init_landscape[0:nbrow-1,0:nbcolumn]


##now to read in the study area raster file
filename_studyarea = '~\\study_area_updated_21_11_ascii' # study area ascii as provided by the user

my_studyarea=habitat_suitability.readMap(filename_studyarea) #  read map of shape 


my_studyarea_resized=my_studyarea[0:my_studyarea.shape[0]-1,0:my_studyarea.shape[1]]


####################################### Read trap lines
## Define path to ascii file indicating the density of traps in each raster cells
filename_trap = '~\\Maintenance_traps_500_buffer_150_ASCII' # network of traps
## Load  density map
my_trap_line = habitat_suitability.readMap(filename_trap) # read map of shape
## reshape density map
my_trap_density = my_trap_line[0:my_trap_line.shape[0]-1,0:my_trap_line.shape[1]]
my_trap_density.shape


# Names of output folder where simulation outcomes will be saved
output_folder = 'Outcomes_23'
if not os.path.exists(output_folder):
	os.makedirs(output_folder)


################### Define simulation parameters, most of them are being defined as lists
nbrep = 50 # number of replications for unique set of parameters
simulationTime =  40  # simulation time in years 
resolution = [200]  # Resolution of the analysis (between 200 and 2000 m )
species= ['possum'] # names of the species (can only be 'possum' at the moment)
max_distance= [12000] # maximum dispersal distance (can be smaller than the buffer used to generate the Kmap but not smaller)
min_birth = [0.5]  # min reporduction rate per female
mean_birth= [0.7]  # mean reporduction rate per female
max_birth = [1.02] # max reporduction rate per female
life_span = [12] # life sapn in years
init_pop = [100] # number of individuals in the landscape to initiate simulations 
gamma0 = [0.08] # Adult trapability index (g0)
sigma= [59] # half-normal trapability decay  (sigma)
gamma1= [0.08] # Juvenile trapability index
number_of_night_trapping = [25] # number of nights trapping occurs during a trapping session
trapping_frequency= [12] # number of month trapping occur during the year
non_study_area_k = [50] # the % of K each cell is reduced to in the source population


name_scenario = 'Maintenance_high_23' 
# Create a sub-directory for each scenarios tested

scenario_folder = os.path.join(output_folder, name_scenario)
if not os.path.exists(scenario_folder):
	os.makedirs(scenario_folder)


import model_code_06_22


study_parameter= list(([output_folder],[nbrep],[simulationTime*12],resolution,max_distance,species, min_birth, mean_birth, max_birth,life_span,gamma0,sigma,gamma1,init_pop,number_of_night_trapping,trapping_frequency,non_study_area_k,[filename_myhabitat],[filename_studyarea],[filename_trap],[name_scenario]))
filename_parameter= os.path.join(scenario_folder, '00-parameter-scenario' + name_scenario + '.txt')
thefile_parameter = open(filename_parameter, 'w')

for item in study_parameter:
	a=thefile_parameter.write("%s\n" % item)

thefile_parameter.close()


import model_code_06_22
model_code_06_22.main(parameter_combinations)



